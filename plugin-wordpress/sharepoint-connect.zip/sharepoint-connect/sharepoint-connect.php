<?php
/*
Plugin Name: SharePoint Connect
Plugin URI: https://votre-site.com/sharepoint-connect
Description: Connecte Formidable Forms à SharePoint via FastAPI.
Version: 1.0
Author: Votre Nom
Author URI: https://votre-site.com
License: GPL2
Text Domain: sharepoint-connect
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class SharePoint_Connect {

    private static $instance = null;

    // Plugin settings
    private $settings;

    public static function get_instance() {
        if ( self::$instance == null ) {
            self::$instance = new SharePoint_Connect();
        }
        return self::$instance;
    }

    private function __construct() {
        // Initialize settings
        $this->settings = get_option( 'spc_settings', $this->default_settings() );

        // Admin menu
        add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );

        // Register settings
        add_action( 'admin_init', array( $this, 'register_settings' ) );

        // Enqueue admin styles
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_styles' ) );

        // Hook into Formidable Forms
        add_action( 'frm_after_create_entry', array( $this, 'send_files_to_fastapi' ), 10, 2 );

        // Load plugin textdomain for translations
        add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
    }

    private function default_settings() {
        return array(
            'form_id'           => '',
            'fastapi_url'      => '',
            'api_token'        => '',
            'field_mappings'   => array(
                'name'         => '',
                'date_of_birth'=> '',
                'email'        => '',
                'files'        => '',
            ),
            'relative_file_path' => 'wp-content/documents-private/',
        );
    }

    public function load_textdomain() {
        load_plugin_textdomain( 'sharepoint-connect', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    }

    public function add_admin_menu() {
        add_options_page(
            __( 'SharePoint Connect', 'sharepoint-connect' ),
            __( 'SharePoint Connect', 'sharepoint-connect' ),
            'manage_options',
            'sharepoint-connect',
            array( $this, 'settings_page' )
        );
    }

    public function register_settings() {
        register_setting( 'spc_settings_group', 'spc_settings', array( $this, 'sanitize_settings' ) );

        add_settings_section(
            'spc_main_section',
            __( 'Paramètres Principaux', 'sharepoint-connect' ),
            null,
            'sharepoint-connect'
        );

        // Form ID
        add_settings_field(
            'form_id',
            __( 'ID du Formulaire', 'sharepoint-connect' ),
            array( $this, 'form_id_callback' ),
            'sharepoint-connect',
            'spc_main_section'
        );

        // FastAPI URL
        add_settings_field(
            'fastapi_url',
            __( 'URL de FastAPI', 'sharepoint-connect' ),
            array( $this, 'fastapi_url_callback' ),
            'sharepoint-connect',
            'spc_main_section'
        );

        // API Token
        add_settings_field(
            'api_token',
            __( 'Token API', 'sharepoint-connect' ),
            array( $this, 'api_token_callback' ),
            'sharepoint-connect',
            'spc_main_section'
        );

        // Field Mappings
        add_settings_field(
            'field_mappings',
            __( 'Mappages des Champs', 'sharepoint-connect' ),
            array( $this, 'field_mappings_callback' ),
            'sharepoint-connect',
            'spc_main_section'
        );

        // Relative File Path
        add_settings_field(
            'relative_file_path',
            __( 'Chemin Relatif des Fichiers', 'sharepoint-connect' ),
            array( $this, 'relative_file_path_callback' ),
            'sharepoint-connect',
            'spc_main_section'
        );
    }

    public function sanitize_settings( $input ) {
        $sanitized = array();

        $sanitized['form_id'] = intval( $input['form_id'] );
        $sanitized['fastapi_url'] = esc_url_raw( $input['fastapi_url'] );
        $sanitized['api_token'] = sanitize_text_field( $input['api_token'] );

        $sanitized['field_mappings'] = array(
            'name'          => sanitize_text_field( $input['field_mappings']['name'] ),
            'date_of_birth' => sanitize_text_field( $input['field_mappings']['date_of_birth'] ),
            'email'         => sanitize_email( $input['field_mappings']['email'] ),
            'files'         => sanitize_text_field( $input['field_mappings']['files'] ),
        );

        $sanitized['relative_file_path'] = sanitize_text_field( $input['relative_file_path'] );

        return $sanitized;
    }

    public function settings_page() {
        ?>
        <div class="wrap">
            <h1><?php _e( 'SharePoint Connect', 'sharepoint-connect' ); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'spc_settings_group' );
                do_settings_sections( 'sharepoint-connect' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    // Callbacks for settings fields
    public function form_id_callback() {
        printf(
            '<input type="number" id="form_id" name="spc_settings[form_id]" value="%s" />',
            esc_attr( $this->settings['form_id'] )
        );
    }

    public function fastapi_url_callback() {
        printf(
            '<input type="url" id="fastapi_url" name="spc_settings[fastapi_url]" value="%s" size="50" />',
            esc_attr( $this->settings['fastapi_url'] )
        );
    }

    public function api_token_callback() {
        printf(
            '<input type="text" id="api_token" name="spc_settings[api_token]" value="%s" size="50" />',
            esc_attr( $this->settings['api_token'] )
        );
    }

    public function field_mappings_callback() {
        $mappings = $this->settings['field_mappings'];
        ?>
        <table class="form-table">
            <tr>
                <th><?php _e( 'Champ', 'sharepoint-connect' ); ?></th>
                <th><?php _e( 'ID du Champ Formidable', 'sharepoint-connect' ); ?></th>
            </tr>
            <tr>
                <td><?php _e( 'Nom', 'sharepoint-connect' ); ?></td>
                <td><input type="text" name="spc_settings[field_mappings][name]" value="<?php echo esc_attr( $mappings['name'] ); ?>" /></td>
            </tr>
            <tr>
                <td><?php _e( 'Date de Naissance', 'sharepoint-connect' ); ?></td>
                <td><input type="text" name="spc_settings[field_mappings][date_of_birth]" value="<?php echo esc_attr( $mappings['date_of_birth'] ); ?>" /></td>
            </tr>
            <tr>
                <td><?php _e( 'Email', 'sharepoint-connect' ); ?></td>
                <td><input type="text" name="spc_settings[field_mappings][email]" value="<?php echo esc_attr( $mappings['email'] ); ?>" /></td>
            </tr>
            <tr>
                <td><?php _e( 'Fichiers', 'sharepoint-connect' ); ?></td>
                <td><input type="text" name="spc_settings[field_mappings][files]" value="<?php echo esc_attr( $mappings['files'] ); ?>" /></td>
            </tr>
        </table>
        <p class="description"><?php _e( 'Entrez les IDs des champs de votre formulaire Formidable Forms.', 'sharepoint-connect' ); ?></p>
        <?php
    }

    public function relative_file_path_callback() {
        printf(
            '<input type="text" id="relative_file_path" name="spc_settings[relative_file_path]" value="%s" size="50" />',
            esc_attr( $this->settings['relative_file_path'] )
        );
        echo '<p class="description">' . __( 'Chemin relatif vers le répertoire des fichiers attachés.', 'sharepoint-connect' ) . '</p>';
    }

    public function enqueue_admin_styles( $hook ) {
        if ( $hook !== 'settings_page_sharepoint-connect' ) {
            return;
        }
        wp_enqueue_style( 'spc_admin_css', plugin_dir_url( __FILE__ ) . 'assets/css/admin.css', array(), '1.0' );
    }

    /**
     * Fonction principale pour envoyer les fichiers à FastAPI
     */
    public function send_files_to_fastapi( $entry_id, $form_id ) {
        if ( $form_id != $this->settings['form_id'] ) { // Vérifie le Form ID
            return;
        }

        // Récupère les champs mappés depuis les paramètres
        $name_field = $this->settings['field_mappings']['name'];
        $dob_field = $this->settings['field_mappings']['date_of_birth'];
        $email_field = $this->settings['field_mappings']['email'];
        $files_field = $this->settings['field_mappings']['files'];

        // Récupère les données de l'entrée
        $entry = FrmEntry::getOne( $entry_id, true );
        $name = FrmProEntriesController::get_field_value( $entry, $name_field );
        $date_of_birth = FrmProEntriesController::get_field_value( $entry, $dob_field );
        $email = FrmProEntriesController::get_field_value( $entry, $email_field );

        // Récupère les fichiers
        $files = FrmProEntriesController::get_field_value( $entry, $files_field );

        if ( empty( $files ) || ! is_array( $files ) ) {
            return;
        }

        $files_and_docs = [];

        foreach ( $files as $file ) {
            if ( isset( $file['id'] ) && isset( $file['description'] ) ) {
                $file_id = intval( $file['id'] ); // ID du fichier
                $doc_type = sanitize_text_field( $file['description'] ); // Type de document

                $file_path = $this->resolve_file_path( $file_id );
                if ( $file_path && file_exists( $file_path ) ) {
                    $files_and_docs[] = array(
                        'file' => $file_path,
                        'type' => $doc_type
                    );
                }
            }
        }

        if ( empty( $files_and_docs ) ) {
            return;
        }

        // Prépare les données POST pour FastAPI
        $post_fields = array(
            'name' => sanitize_text_field( $name ),
            'date_of_birth' => sanitize_text_field( $date_of_birth ),
            'email' => sanitize_email( $email ),
        );

        foreach ( $files_and_docs as $index => $file_doc ) {
            $file_path = $file_doc['file'];
            $doc_type = $file_doc['type'];

            if ( file_exists( $file_path ) ) {
                $post_fields[ "file_$index" ] = new CURLFile( $file_path );
                $post_fields[ "description_$index" ] = $doc_type;
            }
        }

        // Initialise cURL
        $ch = curl_init();

        // Définir les options cURL
        curl_setopt( $ch, CURLOPT_URL, $this->settings['fastapi_url'] );
        curl_setopt( $ch, CURLOPT_POST, true );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $post_fields );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: multipart/form-data',
            'X-API-Token: ' . $this->settings['api_token']
        ) );

        // Exécuter la requête POST
        $response = curl_exec( $ch );

        // Vérifier les erreurs cURL
        if ( $response === false ) {
            $error = curl_error( $ch );
            error_log( "cURL Error: $error" );
            curl_close( $ch );
            return;
        }

        // Obtenir le code de réponse HTTP
        $http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
        curl_close( $ch );

        // Gérer la réponse
        if ( $http_code >= 200 && $http_code < 300 ) {
            // Succès - Optionnellement traiter la réponse
            // Par exemple, vous pouvez enregistrer une note dans l'entrée
            // FrmEntry::update_entry_meta( $entry_id, 'spc_response', $response );
        } else {
            // Enregistrer l'erreur
            error_log( "FastAPI responded with status code $http_code. Response: $response" );
        }
    }

    /**
     * Résout le chemin du fichier en fonction de l'ID
     */
    private function resolve_file_path( $file_id ) {
        $relative_path = trailingslashit( $this->settings['relative_file_path'] );
        $file_name = basename( get_attached_file( $file_id ) );

        // Construire le chemin relatif complet
        $file_path = ABSPATH . $relative_path . $file_name;

        // Modifier les permissions pour rendre le fichier lisible
        $this->make_file_readable( $file_path );

        // Vérifier si le fichier existe et est lisible
        if ( file_exists( $file_path ) && is_readable( $file_path ) ) {
            return $file_path;
        } else {
            error_log( "Fichier introuvable ou non lisible : $file_path" );
        }

        return false;
    }

    /**
     * Modifie les permissions du fichier pour le rendre lisible
     */
    private function make_file_readable( $file_path ) {
        if ( ! file_exists( $file_path ) ) {
            error_log( "Fichier introuvable : $file_path" );
            return false;
        }

        if ( chmod( $file_path, 0644 ) ) {
            error_log( "Permissions modifiées pour le fichier : $file_path" );
            return true;
        } else {
            error_log( "Impossible de modifier les permissions du fichier : $file_path" );
            return false;
        }
    }
}

// Initialiser le plugin
SharePoint_Connect::get_instance();

?>
